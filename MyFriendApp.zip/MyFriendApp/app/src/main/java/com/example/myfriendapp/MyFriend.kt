package com.example.myfriendapp

data class MyFriend(
    val nama : String,
    val kelamin : String,
    val email : String,
    val telp: String,
    val alamat: String
)
